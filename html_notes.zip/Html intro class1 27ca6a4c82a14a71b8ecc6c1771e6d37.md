# Html intro class1

heading(h1-h6)

```jsx
<h1> web tech</h1>
```

we can use elemets like main,secton to nest 2 or more elements together.

while the figure element represents self-contained content and will allow you to associate an image with a caption. **figcaption** element is used to add a caption to describe the image contained within the **figure** element.

```jsx
<figure>      
        <img src="https://cdn.freecodecamp.org/curriculum/cat-photo-app/lasagna.jpg" alt="A slice of lasagna on a plate.">
         <figcaption>Cats love lasagna</figcaption>
</figure>
```

inserting vedio or audio can be done like

```jsx
<audio controls>
  <source src="horse.ogg" type="audio/ogg">
  <source src="horse.mp3" type="audio/mpeg">
</audio>

<video width="320" height="240" controls>
  <source src="movie.mp4" type="video/mp4">
  <source src="movie.ogg" type="video/ogg">
</video>
```

list in html

view content in html list

```jsx
<ol>
<li>cat</li>
<li>dog</li>
</ol>
```

   Defines paragraph

```jsx
<p> this is first try in notion </p>
```

i frame maps

[https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3940.408701463905!2d38.7623521738677!3d9.026430289031541!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x164b852e2eaeb2ef%3A0x90c7ada1472dc75a!2s4%20Kilo%20National%20Palace!5e0!3m2!1sen!2set!4v1700296094008!5m2!1sen!2set](https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3940.408701463905!2d38.7623521738677!3d9.026430289031541!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x164b852e2eaeb2ef%3A0x90c7ada1472dc75a!2s4%20Kilo%20National%20Palace!5e0!3m2!1sen!2set!4v1700296094008!5m2!1sen!2set)

what we did with this map is we copied the link from google then embed the link to our notes which brings the map itself.

 

to build a table 

```jsx
<table>
  <tr>
    <th>Company</th>
    <th>Contact</th>
    <th>Country</th>
  </tr>
  <tr>
    <td>Alfreds Futterkiste</td>
    <td>Maria Anders</td>
    <td>Germany</td>
  </tr>
  <tr>
    <td>Centro comercial Moctezuma</td>
    <td>Francisco Chang</td>
    <td>Mexico</td>
  </tr>
</table>
```

buttons

- <button type="button">Click me</button>

```jsx

```

Div element define a division or section in html document

```jsx
<div>
<p>
any statment by giving the a class to the div we can link it in css which will allow us to design it 
way we want
</p>
</div>
```

![1700292623388.jpg](Html%20intro%20class1%2027ca6a4c82a14a71b8ecc6c1771e6d37/1700292623388.jpg)

html file path 

![html file path.PNG](Html%20intro%20class1%2027ca6a4c82a14a71b8ecc6c1771e6d37/html_file_path.png)

to link a web site

```jsx

<a href="website-link-goes-here" target="_blank">title you want to be seen</a>
```

due to the target element When the user clicks on the link, a new browser tab will automatically open to that page.

 Html frame 

Check boxes 

<input type=”checkbox”>

Let users select zero or more options of limited number of choices

html forms

An HTML form is used to collect user input. The user input is most often sent to a server for processing.

using the `type` attribute. we can easily create a password field,  date, text, reset button, or a control to let users select a file from their computer.

`label` elements are used to help associate the text for an `input` element with the `input` element itself (especially for assistive technologies like screen readers).

```jsx
<form action="/submit" method="post">
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" required>

    <input type="submit" value="Submit">
</form>
```

```jsx
<form>
      <label>cookie type</label>
      <input name="cookie type" /><br />
      <lable>quantity</lable>
      <input name="quantity" /><br />
      <label>delivery date</label>
      <input name="date" type="date" /><br />
      <button>order</button>
    </form>

<form action="https://freecatphotoapp.com/submit-cat-photo">
<fieldset>
<!--The fieldset element is used to group related inputs and labels together in a web form-->        
          <label><input id="indoor" type="radio" name="indoor-outdoor" value="indoor"> Indoor</label>
          <label><input id="outdoor" type="radio" name="indoor-outdoor" value="outdoor"> Outdoor</label>
        </fieldset>
<!--without a value attribute, the form data will include indoor-outdoor=on, which is not useful when you have multiple buttons.-->
<input type="text" name="catphotourl" placeholder="cat photo URL" required> <br>
          <button>Submit</button>

</form>
```

# The <form> Element

The HTML `<form>` element is used to create an HTML form for user input:

<form>.*form elements*.</form>

The `<form>` element is a container for different types of input elements, such as: text fields, checkboxes, radio buttons, submit buttons, etc.

All the different form elements are covered in this chapter: [HTML Form Elements](https://www.w3schools.com/html/html_form_elements.asp).

# The HTML <form> Elements

The HTML `<form>` element can contain one or more of the following form elements:

- `<input>`
- `<label>`
- `<select>`
- `<textarea>`
- `<button>`
- `<fieldset>`
- `<legend>`
- `<datalist>`
- `<output>`
- `<option>`
- `<optgroup>`

---

# The <input> Element

One of the most used form elements is the `<input>` element.

The `<input>` element can be displayed in several ways, depending on the `type` attribute.

# The <label> Element

The `<label>` element defines a label for several form elements.

The `<label>` element is useful for screen-reader users, because the screen-reader will read out loud the label when the user focus on the input element.

The `<label>` element also help users who have difficulty clicking on very small regions (such as radio buttons or checkboxes) - because when the user clicks the text within the `<label>` element, it toggles the radio button/checkbox.

The `for` attribute of the `<label>` tag should be equal to the `id` attribute of the `<input>` element to bind them together.

---

# The <select> Element

The `<select>` element defines a drop-down list:

# Example

```jsx
<label for="cars">Choose a car:</label><select id="cars" name="cars">  <option value="volvo">Volvo</option>  <option value="saab">Saab</option>  <option value="fiat">Fiat</option>  <option value="audi">Audi</option></select>
```

The `<option>` element defines an option that can be selected.

By default, the first item in the drop-down list is selected.

To define a pre-selected option, add the `selected` attribute to the option:

# Example

```jsx
<option value="fiat" selected>Fiat</option>
```

# Visible Values:

Use the `size` attribute to specify the number of visible values:

# Example

```jsx
<label for="cars">Choose a car:</label><select id="cars" name="cars" size="3">  <option value="volvo">Volvo</option>  <option value="saab">Saab</option>  <option value="fiat">Fiat</option>  <option value="audi">Audi</option></select>
```

# Allow Multiple Selections:

Use the `multiple` attribute to allow the user to select more than one value:

# Example

```jsx
<label for="cars">Choose a car:</label><select id="cars" name="cars" size="4" ****multiple>  <option value="volvo">Volvo</option>  <option value="saab">Saab</option>  <option value="fiat">Fiat</option>  <option value="audi">Audi</option></select>
```

---

# The <textarea> Element

The `<textarea>` element defines a multi-line input field (a text area):

# Example

```jsx
<textarea name="message" rows="10" cols="30">The cat was playing in the garden.</textarea>
```

The `rows` attribute specifies the visible number of lines in a text area.

The `cols` attribute specifies the visible width of a text area.

This is how the HTML code above will be displayed in a browser:

You can also define the size of the text area by using CSS:

# Example

```jsx
<textarea name="message" style="width:200px; height:600px;">The cat was playing in the garden.</textarea>
```

---

---

# The <button> Element

The `<button>` element defines a clickable button:

# Example

```jsx
<button type="button" onclick="alert('Hello World!')">Click Me!</button>
```

**Note:** Always specify the `type` attribute for the button element. Different browsers may use different default types for the button element.

---

# The <fieldset> and <legend> Elements

The `<fieldset>` element is used to group related data in a form.

The `<legend>` element defines a caption for the `<fieldset>` element.

# Example

```jsx
<form action="/action_page.php">  <fieldset>    <legend>Personalia:</legend>    <label for="fname">First name:</label><br>    <input type="text" id="fname" name="fname" value="John"><br>    <label for="lname">Last name:</label><br>    <input type="text" id="lname" name="lname" value="Doe"><br><br>    <input type="submit" value="Submit">  </fieldset></form>
```

This is how the HTML code above will be displayed in a browser:

Personalia:First name:Last name:

---

# The <datalist> Element

The `<datalist>` element specifies a list of pre-defined options for an `<input>` element.

Users will see a drop-down list of the pre-defined options as they input data.

The `list` attribute of the `<input>` element, must refer to the `id` attribute of the `<datalist>` element.

# Example

```jsx
<form action="/action_page.php">  <input list="browsers">  <datalist id="browsers">    <option value="Edge">    <option value="Firefox">    <option value="Chrome">    <option value="Opera">    <option value="Safari">  </datalist></form>
```

---

# The <output> Element

The `<output>` element represents the result of a calculation (like one performed by a script).

# Example

Perform a calculation and show the result in an `<output>` element:

```jsx
<form action="/action_page.php"  oninput="x.value=parseInt(a.value)+parseInt(b.value)">  0  <input type="range"  id="a" name="a" value="50">  100 +  <input type="number" id="b" name="b" value="50">  =  <output name="x" for="a b"></output>  <br><br>  <input type="submit"></form>
```